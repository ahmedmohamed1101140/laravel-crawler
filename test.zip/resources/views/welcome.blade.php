<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

    </head>
    <body>
        <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}">Home</a>
                    @else
                        <a href="{{ route('login') }}">Login</a>
                        <a href="{{ route('register') }}">Register</a>
                    @endauth
                </div>
            @endif

            <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
              @if($sec_url[1] !== 'ahmed')
                <div class="card-header">{{$sec_url[1]}}</div>
              @endif

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                        <form action="{{url('/test')}}" method="post">
                            @csrf
                            Souq Product URL
                            <input style="width: 100%" type="text" name="url">
                        </form>
                </div>
            </div>
        </div>
    </div>
</div>
        </div>
    </body>
</html>
