<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>
<h2>Sending Email in Laravel 5.5</h2>

<div>
    Hello {{$name}} This is test message
    Email: {{ $email }}
    Message: {{ $user_message }}
</div>

</body>
</html>
