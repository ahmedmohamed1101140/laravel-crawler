<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>
                        <a href="<?php echo e(route('register')); ?>">Register</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
              <?php if($sec_url[1] !== 'ahmed'): ?>
                <div class="card-header"><?php echo e($sec_url[1]); ?></div>
              <?php endif; ?>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                        <form action="<?php echo e(url('/test')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            Souq Product URL
                            <input style="width: 100%" type="text" name="url">
                        </form>
                </div>
            </div>
        </div>
    </div>
</div>
        </div>
    </body>
</html>
