<!DOCTYPE html>
<html>
<head>
    <title>Laravel 5.4 Cloudways Contact US Form Example</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h1>Contact US Form</h1>

    <?php if(Session::has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(Session::get('success')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(url('/mail')); ?>" method="post">

    <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
        <?php echo csrf_field(); ?>
        <input type="text" name="name">
        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
    </div>

    <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
        <input type="text" name="email">
        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
    </div>

    <div class="form-group <?php echo e($errors->has('message') ? 'has-error' : ''); ?>">
        <input type="text" name="message">
        <span class="text-danger"><?php echo e($errors->first('message')); ?></span>
    </div>

    <div class="form-group">
        <button class="btn btn-success" type="submit">Contact US!</button>
    </div>
    </form>

</div>

</body>
</html>