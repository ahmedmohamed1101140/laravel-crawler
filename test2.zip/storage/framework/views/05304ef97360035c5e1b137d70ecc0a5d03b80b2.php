<?php $__env->startSection('css'); ?>
    <style>
    .switch {
    position: relative;
    display: inline-block;
    width: 60px;
    height: 34px;
    }

    .switch input {display:none;}

    .slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    -webkit-transition: .4s;
    transition: .4s;
    }

    .slider:before {
    position: absolute;
    content: "";
    height: 26px;
    width: 26px;
    left: 4px;
    bottom: 4px;
    background-color: white;
    -webkit-transition: .4s;
    transition: .4s;
    }

    input:checked + .slider {
    background-color: #2196F3;
    }

    input:focus + .slider {
    box-shadow: 0 0 1px #2196F3;
    }

    input:checked + .slider:before {
    -webkit-transform: translateX(26px);
    -ms-transform: translateX(26px);
    transform: translateX(26px);
    }

    /* Rounded sliders */
    .slider.round {
    border-radius: 34px;
    }

    .slider.round:before {
    border-radius: 50%;
    }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Dashboard</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    Welcome To your dashboard add and track website's items
                </div>
            </div>
        </div>
</div>
<div class="container">
    <div class="py-5 text-center">
        
        <h2>Chan Scan</h2>
        <p class="lead">Below is a Demo made for tracking the products by providing the link of the product from
            <span class="badge badge-primary badge-pill"> Souq</span><br>
            To get products last update hit Refresh and all your products will be up to date
        </p>
    </div>

    
    
        
            
                
                    
                        
                    
                    
                    
                        
                
            
        
    
    


    <div class="row">
        <div class="col-md-5 order-md-2 mb-4">
            <h4 class="d-flex justify-content-between align-items-center mb-3">
                <span class="text-muted">Your Products</span>
                

                <span class="badge badge-primary badge-pill"> <?php echo e(Auth::user()->products->count()); ?></span>
            </h4>
            <ul class="list-group mb-3">
                <?php $__currentLoopData = Auth::user()->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item d-flex justify-content-between lh-condensed">
                        <div>
                            <a href="<?php echo e($product->link); ?>">
                                <h6 class="my-0"><?php echo e($product->name); ?></h6>
                            </a>
                            <?php if(strlen($product->amount) < 10): ?>
                                <small class="text-muted">Not Found Try Later</small>
                            <?php else: ?>
                                <small class="text-muted"><?php echo e($product->amount); ?></small>
                            <?php endif; ?>
                            <br>
                            <small class="text-muted">last refresh: <?php echo e($product->updated_at->diffForHumans()); ?></small>
                            <br>
                            <div class="row">
                                <div class="col-md-2">
                                    <?php if($product->type =='souq'): ?>
                                        <span class="badge badge-primary "> Souq</span>
                                    <?php elseif($product->type =='amazon'): ?>
                                        <span class="badge badge-success "> Amazon</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger "> not found</span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                    <a href="<?php echo e(url('/delete/'.$product->id)); ?>" style="width: 90px; margin-left: 244px;" class="btn btn-danger">Delete</a>
                                </div>
                            </div>
                        </div>
                        <span class="text-muted"><?php echo e($product->price); ?></span>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <form class="card p-2" method="post" action="<?php echo e(url('/refresh')); ?>">
                <?php echo csrf_field(); ?>
                <div class="input-group">
                    <button type="submit" style="width: 428px;" class="btn btn-success">Refresh</button>
                </div>
            </form>

            
                
                
                    
                    
                

            
            <h4  class="d-flex justify-content-between align-items-center mb-3">
            </h4>

        </div>
        <div class="col-md-7 order-md-1">
            <h4 class="mb-3">Add New Product</h4>
            <form method="post" action="<?php echo e(url('/add')); ?>" >
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="username">Product Link</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">!</span>
                        </div>
                        <input type="text" class="form-control" id="link" name="link" placeholder="link" required>
                    </div>
                </div>
                <h4 class="mb-3">Web Site</h4>

                <div class="d-block my-3">
                    <div class="custom-control custom-radio">
                        <input id="credit" value="souq" name="paymentMethod" type="radio" class="custom-control-input" checked required>
                        <label class="custom-control-label" for="credit">Souq</label>
                    </div>
                    
                        
                        
                    
                    
                        
                        
                    
                </div>
                <button class="btn btn-primary btn-lg btn-block" type="submit">Add Product</button>
            </form>
        </div>
    </div>

    <footer class="my-5 pt-5 text-muted text-center text-small">
        <p class="mb-1">© 2017-2018 Created by <a href="https://maxeseg.com/">Maxseg.com</a></p>
    </footer>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>





    <script type="text/javascript">
        function myFunction () {
            console.log('Executed!');
            
                
                
                
                

                
                







                
                
                    
                
            
        }

        var interval = setInterval(function () { myFunction(); }, 6000);
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>