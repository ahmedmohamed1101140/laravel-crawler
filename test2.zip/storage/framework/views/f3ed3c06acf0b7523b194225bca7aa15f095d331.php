<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <main role="main">
        <section class="jumbotron text-center">
                <h1 class="jumbotron-heading">Chan Scan</h1>
                <p class="lead">Below is a Demo made for tracking the products by providing the link of the product from <span class="badge badge-primary badge-pill"> Souq</span><br> To get products last update hit Refresh and all your products will be up to date</p>
                   <div class="container">
                       <form method="post" action="<?php echo e(url('/add')); ?>" >
                           <?php echo csrf_field(); ?>
                           <div class="input-group mb-3">
                               <div class="input-group-prepend">
                                   <label class="input-group-text" for="inputGroupSelect01">Product Link</label>
                               </div>
                               <input type="text" name="link" class="form-control" placeholder="www.souq.com/productx" aria-label="Recipient's username" aria-describedby="button-addon2">
                               <input type="hidden" name="paymentMethod"  value="souq" class="form-control" placeholder="www.souq.com/productx" aria-label="Recipient's username" aria-describedby="button-addon2">

                               <div class="input-group-append">
                                   <button class="btn btn-outline-primary" type="submit" id="button-addon2"><i class="fa fa-search"></i> Scan</button>
                               </div>
                           </div>
                       </form>

                   </div>

        </section>

        <?php echo $__env->make('layouts.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="album py-5 bg-light">
            <div class="container">

                <div class="card">
                    <div class="card-body">
                        <div style="height:27px;" class="d-flex justify-content-between align-items-center">
                            <h3 style="margin-top: 8px;"><span class="badge badge-primary badge-pill"><?php echo e(Auth::user()->products->count()); ?></span> Product in your List</h3>
                            <?php if( Auth::user()->products->count() > 0): ?>
                            <a href="<?php echo e(url('/refresh')); ?>" class="btn btn-success my-2"><i class="fa fa-refresh"></i> Refresh</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <br><br>
                <div class="row">
                    <?php $__currentLoopData = Auth::user()->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <div class="col-md-4">
                        <div class="card mb-4 shadow-sm">
                            <div class="d-flex align-items-center p-3  text-white-50 bg-purple rounded shadow-sm">
                                <a href="https://egypt.souq.com">
                                    <img class="mr-3" src="<?php echo e(asset('img/souq.jpg')); ?>" alt="" width="48" height="48">
                                </a>
                                <div class="lh-100">
                                    <h6 class="mb-0 text-white lh-100"><a style="color: whitesmoke" href="https://egypt.souq.com">Souq.com</a></h6>
                                </div>
                            </div>
                            <div class="card-body">
                                <a href="<?php echo e($product->link); ?>">
                                    <p class="card-text" style="height: 80px;">
                                        <?php echo e($product->name); ?> <br>
                                    </p>
                                </a>
                                <div class="d-flex justify-content-between align-items-center">
                                    <h5>
                                        <span class="badge badge-success ">Price:  <?php echo e($product->price); ?></span>
                                    </h5>
                                    <h5>
                                        <span class="badge badge-warning"><?php echo e($product->amount); ?></span>
                                    </h5>

                                </div>
                                <small class="text-muted">Last Refresh: <?php echo e($product->updated_at->diffForHumans()); ?></small>
                                <br>

                                <ul class="list-group">
                                    <?php $__currentLoopData = $product->amounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <?php echo e($amount->amount); ?>

                                        <span class="badge badge-primary badge-pill">Since <?php echo e($amount->created_at->diffForHumans()); ?></span>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <br>
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                        <a href="<?php echo e(url('/delete/'.$product->id)); ?>" style="width: 308px;" class="btn btn-outline-danger">Delete</a>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

    </main>

    <footer class="my-5 pt-5 text-muted text-center text-small">
        <div class="container">
            <p class="float-right">
                <a href="#">Back to top</a>
            </p>
            <p class="mb-1">© 2017-2018 Created by <a href="https://maxeseg.com/">Maxeseg.com</a></p>
        </div>
    </footer>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>